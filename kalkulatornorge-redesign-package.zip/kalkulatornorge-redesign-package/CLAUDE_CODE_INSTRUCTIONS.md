# KALKULATORNORGE.NO REDESIGN - IMPLEMENTATION GUIDE FOR CLAUDE CODE

## 🎯 OVERVIEW
Redesign the entire site from teal gradient to a warm Claude.ai-inspired cream/terracotta aesthetic.

**Primary Color (Rich Rust):** `#C4533A`
**Background:** `#FAF9F7` (warm cream)
**Surface/Cards:** `#FFFFFF`

---

## 📁 FILE STRUCTURE

Create/update these files:
```
kalkulatornorge/
├── css/
│   ├── design-system.css    (NEW - core variables & reset)
│   ├── components.css       (NEW - all UI components)
│   └── seo-content.css      (UPDATE - match new design)
├── icons/                   (NEW folder)
│   ├── icon-briefcase.svg
│   ├── icon-wallet.svg
│   ├── icon-moneybag.svg
│   ├── icon-clock.svg
│   ├── icon-house.svg
│   ├── icon-car.svg
│   ├── icon-hospital.svg
│   ├── icon-plug.svg
│   ├── icon-family.svg
│   ├── icon-beach.svg
│   ├── icon-babycart.svg
│   ├── icon-trailer.svg
│   ├── icon-van.svg
│   └── icon-chart.svg
├── index.html               (UPDATE)
├── skatt.html               (UPDATE)
├── brutto-netto.html        (UPDATE)
├── feriepenger.html         (UPDATE)
├── barnebidrag.html         (UPDATE)
├── sykepenger.html          (UPDATE)
├── overtid.html             (UPDATE)
├── pendlerfradrag.html      (UPDATE)
├── arbeidsgiveravgift.html  (UPDATE)
├── bilkostnad.html          (UPDATE)
├── stromkostnad.html        (UPDATE)
├── tilhengervekt.html       (UPDATE)
├── timelonn-frilanser.html  (UPDATE)
└── personvern.html          (UPDATE)
```

---

## 🎨 ICON MAPPING

### Rename uploaded icons as follows:
| Original File | New Name | Used For |
|---------------|----------|----------|
| Union.svg | icon-briefcase.svg | Jobb & Lønn, Arbeidsgiveravgift |
| Subtract.svg | icon-wallet.svg | Brutto/Netto, Timelønn |
| Union-1.svg | icon-moneybag.svg | Skattekalkulator, Næring category |
| Union-2.svg | icon-clock.svg | Overtid |
| Union-3.svg | icon-plug.svg | Strømkostnad |
| Union-4.svg | icon-babycart.svg | Barnebidrag |
| Union-6.svg | icon-trailer.svg | Tilhengervekt |
| Union-8.svg | icon-family.svg | Familie & Helse category |
| Subtract-1.svg | icon-car.svg | Bilkostnad, Transport category |
| Subtract-3.svg | icon-hospital.svg | Sykepenger |
| Subtract-5.svg | icon-van.svg | Pendlerfradrag |
| Subtract-7.svg | icon-house.svg | Husholdning category |
| Ellipse 19.svg | icon-beach.svg | Feriepenger |

### Calculator-to-Icon Assignment:
| Calculator | Icon File |
|------------|-----------|
| Skattekalkulator | icon-moneybag.svg |
| Brutto/Netto Lønn | icon-wallet.svg |
| Feriepengekalkulator | icon-beach.svg |
| Sykepenger | icon-hospital.svg |
| Overtidsbetaling | icon-clock.svg |
| Arbeidsgiveravgift | icon-briefcase.svg |
| Timelønn for Frilansere | icon-wallet.svg |
| Strømkostnad | icon-plug.svg |
| Bilkostnad | icon-car.svg |
| Barnebidrag | icon-babycart.svg |
| Pendlerfradrag | icon-van.svg |
| Tilhengervekt | icon-trailer.svg |

### Category Icons:
| Category | Icon File |
|----------|-----------|
| Jobb & Lønn | icon-briefcase.svg |
| Husholdning | icon-house.svg |
| Familie & Helse | icon-family.svg |
| Transport | icon-car.svg |
| Næring | icon-moneybag.svg |

---

## 📝 STEP-BY-STEP IMPLEMENTATION

### STEP 1: Create CSS folder and files
```bash
mkdir -p css icons
```

Copy the provided `design-system.css` and `components.css` into the `css/` folder.

### STEP 2: Rename and organize icons
Move all SVG icons to `icons/` folder with new names as specified above.

### STEP 3: Add Google Fonts to ALL HTML files
In the `<head>` of every HTML file, add:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
```

### STEP 4: Link new CSS files in ALL HTML files
Replace old CSS links with:
```html
<link rel="stylesheet" href="css/design-system.css">
<link rel="stylesheet" href="css/components.css">
```

### STEP 5: Update index.html (Landing Page)

**Remove:**
- All inline styles with gradients
- Old teal/green colors
- Purple table headers

**Update structure:**
```html
<!DOCTYPE html>
<html lang="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Norske Kalkulatorer 2026 | Gratis beregningsverktøy</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Styles -->
    <link rel="stylesheet" href="css/design-system.css">
    <link rel="stylesheet" href="css/components.css">
</head>
<body>
    <!-- HEADER -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="index.html" class="logo">
                    <div class="logo-icon">
                        <!-- Embed briefcase SVG inline with white fill -->
                    </div>
                    <span class="logo-text">Kalkulatornorge.no</span>
                </a>
                <nav class="nav-links">
                    <a href="#kalkulatorer" class="nav-link">Alle kalkulatorer</a>
                    <a href="#om-oss" class="nav-link">Om oss</a>
                    <a href="personvern.html" class="nav-link">Personvern</a>
                </nav>
            </div>
        </div>
    </header>
    
    <!-- HERO -->
    <section class="hero">
        <div class="container">
            <span class="hero-badge">✨ Oppdatert for 2026</span>
            <h1>Norske Kalkulatorer 2026</h1>
            <p class="hero-subtitle">Gratis og enkle beregningsverktøy for 2026</p>
            
            <!-- Feature Pills -->
            <div class="feature-pills">
                <!-- ... feature pills ... -->
            </div>
            
            <!-- Search Bar -->
            <div class="search-container">
                <div class="search-bar">
                    <input type="text" class="search-input" id="search" placeholder="Søk etter kalkulator...">
                    <!-- Search icon SVG -->
                </div>
            </div>
            
            <!-- Quick Access -->
            <div class="quick-access">
                <!-- Quick buttons with correct icons -->
            </div>
            
            <!-- Stats -->
            <div class="stats-row">
                <div class="stat-box">
                    <div class="stat-number">12</div>
                    <div class="stat-label">Kalkulatorer</div>
                </div>
                <!-- ... more stats ... -->
            </div>
        </div>
    </section>
    
    <!-- CALCULATOR CATEGORIES -->
    <section class="section" id="kalkulatorer">
        <div class="container">
            <!-- Each category with calculator-grid -->
        </div>
    </section>
    
    <!-- FOOTER -->
    <footer class="footer">
        <!-- ... -->
    </footer>
</body>
</html>
```

### STEP 6: Update Calculator Pages (skatt.html, etc.)

Each calculator page should follow this structure:
```html
<!DOCTYPE html>
<html lang="no">
<head>
    <!-- Same head as index.html -->
</head>
<body>
    <header class="header">
        <!-- Same header -->
    </header>
    
    <main>
        <section class="section" style="background: var(--color-background-alt);">
            <div class="calculator-page">
                <a href="index.html" class="back-btn">
                    <!-- Arrow icon -->
                    Tilbake Hjem
                </a>
                
                <div class="calculator-header">
                    <h1>
                        <!-- Calculator icon -->
                        Skattekalkulator 2026
                    </h1>
                    <p>Beregn din skatt basert på inntekt og fradrag</p>
                </div>
                
                <div class="calculator-box">
                    <div class="form-group">
                        <label class="form-label">Årlig bruttoinntekt (kr)</label>
                        <input type="number" class="form-input" id="income">
                    </div>
                    
                    <!-- More form fields -->
                    
                    <button class="btn btn-primary" onclick="calculate()">
                        Beregn Skatt
                    </button>
                    
                    <!-- Results Box (shown after calculation) -->
                    <div class="results-box" id="results" style="display: none;">
                        <!-- Result rows -->
                    </div>
                </div>
                
                <!-- Info Box -->
                <div class="info-box">
                    <div class="info-box-header">
                        <!-- Info icon -->
                        <h3>Om Skatteberegning 2026</h3>
                    </div>
                    <p><!-- Info text --></p>
                </div>
                
                <!-- SEO Content (if exists) -->
            </div>
        </section>
    </main>
    
    <footer class="footer">
        <!-- Same footer -->
    </footer>
</body>
</html>
```

### STEP 7: Update seo-content.css
Replace the entire file to match new design:
- Use `var(--color-*)` variables
- Remove dark gradient backgrounds
- Use warm cream backgrounds
- Style FAQ accordions with new colors

---

## 🔧 SPECIFIC CHANGES TO MAKE

### Colors to Replace:
| Old Color | New Color |
|-----------|-----------|
| #1FD59B (teal) | #C4533A (rust) |
| #00CED1 (teal) | #C4533A (rust) |
| linear-gradient(...) | #FAF9F7 (solid cream) |
| purple headers | #C4533A (rust) |
| #333, #444 (dark bg) | #FAF9F7 (cream) |

### Remove:
- All gradient backgrounds
- Teal/green accent colors
- Purple table headers
- Dark mode styling (not in new design)
- Emoji icons (replace with SVG icons)

### Add:
- Warm cream background everywhere
- Rich rust (#C4533A) for primary actions
- White cards with subtle borders
- Custom SVG icons
- Source Serif 4 for headings
- Inter for body text

---

## ✅ VERIFICATION CHECKLIST

After implementation, verify:

- [ ] All pages load without errors
- [ ] No old teal/green colors visible
- [ ] No gradients visible
- [ ] All icons display correctly (rust color #C4533A)
- [ ] Fonts load correctly (Source Serif 4, Inter)
- [ ] Calculator forms work correctly
- [ ] Results display properly
- [ ] Mobile responsive works
- [ ] Footer is centered
- [ ] Quick access buttons show correct icons
- [ ] SEO content styled correctly

---

## 📱 RESPONSIVE BREAKPOINTS

- **Desktop:** 1200px+ (full layout)
- **Tablet:** 768px-1199px (adjusted spacing)
- **Mobile:** <768px (single column, hidden nav)

---

## 🚀 DEPLOYMENT

After all changes:
1. Test locally
2. Commit to git
3. Push to GitHub
4. GitHub Pages will auto-deploy

---

## 💡 NOTES

- Keep all existing JavaScript functionality
- Keep Google Analytics and cookie consent
- Keep meta tags for SEO
- Update copyright year to 2026
- All icons should use fill="#C4533A" for consistency
